from django.db import models

class Userinfo(models.Model):
    email=models.CharField(max_length=70)
    password=models.CharField(max_length=60)

    def __str__(self):
        return self.email
    
class Doctorinfo(models.Model):
    doc_img=models.ImageField(upload_to='doctor/')
    doc_name=models.CharField(max_length=60)
    doc_spc=models.CharField(max_length=60)

    def __str__(self):
        return self.doc_name    

class Registerinfo(models.Model):
    doc_name=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    reason=models.CharField(max_length=100)
    date=models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class Patientinfo(models.Model):
    doc_name=models.CharField(max_length=50)
    doc_id=models.CharField(max_length=80)
    def __str__(self):
        return self.doc_name    
    
    
# Create your models here.
