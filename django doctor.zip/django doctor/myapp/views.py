from django.shortcuts import render,redirect
from .models import Userinfo,Doctorinfo,Registerinfo,Patientinfo
from django.contrib import messages

def index(request):
    return render(request,'index.html')

def signup(request):
    if request.method=="POST":
        u_email=request.POST.get('mail')
        u_pass=request.POST.get('passcode')
        u_c_pa=request.POST.get('con_pass')
        user=Userinfo.objects.filter(email=u_email)
        if user.exists():
            messages.error(request,"email already taken")
        elif u_pass != u_c_pa:
            messages.error(request,"password not match")
        else:
            Userinfo.objects.create(email=u_email,password=u_pass)
            return render(request,'login.html')
    return render(request,'signup.html')

def login(request):
    if request.method=="POST":
        u_email=request.POST.get('mail')
        u_pass=request.POST.get('passcode')
        user=Userinfo.objects.filter(email=u_email,password=u_pass)
        if user.exists():
            return redirect('/home/')
        else:
            messages.error(request,"mail password incorrect")
    return render(request,'login.html')

def home(request):
    doc_info=Doctorinfo.objects.all()
    return render(request,'home.html',{'doctors':doc_info})

def form(request,id):
    name=Doctorinfo.objects.get(id=id)
    return render(request,'register.html',{'x':name})

def register(request):
    if request.method=="POST":
        docname=request.POST.get('mail')
        patient_name=request.POST.get('passcode')
        reason=request.POST.get('con_pass')
        date=request.POST.get('con_passcode')
        Registerinfo.objects.create(doc_name=docname,name=patient_name,reason=reason,date=date)
        return render(request,'success.html')
    return render(request,'register.html')

def records(request):
    if request.method=="POST":
        a=request.POST.get('name')
        b=request.POST.get('id')
        user=Patientinfo.objects.filter(doc_name=a,doc_id=b)
        if user.exists():
            return redirect('/patients/')
        else:
            messages.error(request,"check your identity")
    return render(request,'records.html')

def patients(request):
    doc_info=Registerinfo.objects.all()
    return render(request,'patients.html',{'doctors':doc_info})


    


# Create your views here.

