from django.contrib import admin
from .models import Userinfo,Doctorinfo,Registerinfo,Patientinfo

admin.site.register(Userinfo)
admin.site.register(Doctorinfo)
admin.site.register(Registerinfo)
admin.site.register(Patientinfo)


# Register your models here.
